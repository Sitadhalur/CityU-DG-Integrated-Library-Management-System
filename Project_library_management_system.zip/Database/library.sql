/*
 Navicat Premium Dump SQL

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 90300 (9.3.0)
 Source Host           : localhost:3306
 Source Schema         : library

 Target Server Type    : MySQL
 Target Server Version : 90300 (9.3.0)
 File Encoding         : 65001

 Date: 10/12/2025 14:19:31
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book`  (
  `book_id` int NOT NULL AUTO_INCREMENT,
  `book_title` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `author` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `price` int NOT NULL COMMENT 'Price of the book',
  `total_borrowed` int NOT NULL COMMENT 'How many times borrowed',
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT 'Book introduction',
  PRIMARY KEY (`book_id`) USING BTREE,
  INDEX `price`(`price` ASC) USING BTREE,
  INDEX `total_borrowed`(`total_borrowed` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES (1, '1984', 'George Orwell', 18, 215, 'A dystopian story depicting a totalitarian regime where surveillance and propaganda dominate daily life. It follows Winston Smith as he struggles against a government that controls truth itself.');
INSERT INTO `book` VALUES (2, 'Animal Farm', 'George Orwell', 12, 193, 'A political allegory in which farm animals overthrow their human owner. Their attempt to build an equal society collapses as power and corruption reshape the farm’s new leadership.');
INSERT INTO `book` VALUES (3, 'Brave New World', 'Aldous Huxley', 21, 157, 'A futuristic society built on genetic engineering and constant pleasure. Bernard Marx begins questioning a world where individuality is suppressed in favor of artificial stability and control.');
INSERT INTO `book` VALUES (4, 'Fahrenheit 451', 'Ray Bradbury', 18, 111, 'In a society where books are banned and critical thinking is discouraged, fireman Guy Montag begins to question his role in destroying knowledge, sparking a rebellion within himself.');
INSERT INTO `book` VALUES (5, 'Jane Eyre', 'Charlotte Brontë', 15, 126, 'The life of an orphaned girl who grows into a strong, independent woman. Jane’s resilience and moral conviction guide her through hardship, love, and the search for belonging.');
INSERT INTO `book` VALUES (6, 'Moby Dick', 'Herman Melville', 19, 77, 'An epic journey of obsession as Captain Ahab relentlessly hunts the great white whale. The novel blends adventure with deep reflections on fate, nature, and the human spirit.');
INSERT INTO `book` VALUES (7, 'Pride and Prejudice', 'Jane Austen', 15, 120, 'A timeless romantic novel exploring themes of class, reputation, and love through the witty and independent Elizabeth Bennet, whose sharp insights challenge the societal norms of her time.');
INSERT INTO `book` VALUES (8, 'The Alchemist', 'Paulo Coelho', 13, 166, 'A philosophical journey following Santiago, a shepherd who travels across deserts in search of treasure. His quest reveals lessons about destiny, dreams, and the importance of self-discovery.');
INSERT INTO `book` VALUES (9, 'The Catcher in the Rye', 'J.D. Salinger', 17, 130, 'Holden Caulfield narrates his struggles with identity, loneliness, and growing up. The novel captures teenage rebellion and emotional confusion with raw honesty and lasting cultural influence.');
INSERT INTO `book` VALUES (10, 'The Chronicles of Narnia', 'C.S. Lewis', 22, 178, 'A magical world accessed through a wardrobe invites children into battles of good and evil. The series blends adventure and spiritual symbolism in unforgettable fantasy storytelling.');
INSERT INTO `book` VALUES (11, 'The Great Gatsby', 'F. Scott Fitzgerald', 14, 98, 'A tale of wealth, ambition, and illusion in the Jazz Age. Through Nick Carraway’s eyes, the mysterious Jay Gatsby’s pursuit of love reveals the emptiness beneath glittering American dreams.');
INSERT INTO `book` VALUES (12, 'The Hobbit', 'J.R.R. Tolkien', 20, 203, 'Bilbo Baggins is drawn into an unexpected adventure with dwarves and a wizard. The journey, full of danger and wonder, lays the foundation for Tolkien’s epic Middle-earth legend.');
INSERT INTO `book` VALUES (13, 'The Lord of the Rings', 'J.R.R. Tolkien', 25, 230, 'A vast epic following Frodo Baggins as he attempts to destroy a powerful ring. Themes of courage, friendship, and sacrifice define this cornerstone of modern fantasy literature.');
INSERT INTO `book` VALUES (14, 'The Picture of Dorian Gray', 'Oscar Wilde', 16, 143, 'Dorian Gray remains youthful while his portrait ages and reflects his corruption. The novel explores beauty, morality, and the consequences of living without responsibility or restraint.');
INSERT INTO `book` VALUES (15, 'To Kill a Mockingbird', 'Harper Lee', 16, 143, 'A powerful story of racial injustice and moral growth, told through young Scout Finch. Her father, lawyer Atticus Finch, defends an innocent man, challenging prejudice in a divided Southern town.');

-- ----------------------------
-- Table structure for borrow_log
-- ----------------------------
DROP TABLE IF EXISTS `borrow_log`;
CREATE TABLE `borrow_log`  (
  `borrow_id` int NOT NULL,
  `librarian_id` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `process_time` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `finished` int NOT NULL DEFAULT 0 COMMENT 'Whether the borrow is completed',
  PRIMARY KEY (`borrow_id`) USING BTREE,
  INDEX `librarian_id`(`librarian_id` ASC) USING BTREE,
  CONSTRAINT `fk_borrow` FOREIGN KEY (`borrow_id`) REFERENCES `borrow_order` (`borrow_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_librarian` FOREIGN KEY (`librarian_id`) REFERENCES `librarian` (`librarian_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of borrow_log
-- ----------------------------
INSERT INTO `borrow_log` VALUES (4, 'L001', '2025/12/10 13:55:13', 1);
INSERT INTO `borrow_log` VALUES (5, 'L001', '2025/12/10 13:55:15', 0);
INSERT INTO `borrow_log` VALUES (7, 'L001', '2025/12/10 13:56:14', 0);
INSERT INTO `borrow_log` VALUES (8, 'L001', '2025/12/10 13:56:17', 0);

-- ----------------------------
-- Table structure for borrow_method
-- ----------------------------
DROP TABLE IF EXISTS `borrow_method`;
CREATE TABLE `borrow_method`  (
  `method_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `count` int NOT NULL COMMENT 'number of borrows using this method',
  PRIMARY KEY (`method_name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of borrow_method
-- ----------------------------
INSERT INTO `borrow_method` VALUES ('On-site', 67);
INSERT INTO `borrow_method` VALUES ('Online Reservation', 120);

-- ----------------------------
-- Table structure for borrow_order
-- ----------------------------
DROP TABLE IF EXISTS `borrow_order`;
CREATE TABLE `borrow_order`  (
  `borrow_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int UNSIGNED NOT NULL,
  `book_id` int NOT NULL,
  `borrow_method` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `status` int NULL DEFAULT 0,
  `borrow_time` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`borrow_id`) USING BTREE,
  INDEX `idx_user`(`user_id` ASC) USING BTREE,
  INDEX `idx_book`(`book_id` ASC) USING BTREE,
  CONSTRAINT `fk_book_id` FOREIGN KEY (`book_id`) REFERENCES `book` (`book_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of borrow_order
-- ----------------------------
INSERT INTO `borrow_order` VALUES (4, 3, 1, 'On-site', 2, '2025-12-10 13:53:09');
INSERT INTO `borrow_order` VALUES (5, 3, 2, 'On-site', 1, '2025-12-10 13:53:12');
INSERT INTO `borrow_order` VALUES (6, 3, 3, 'On-site', 0, '2025-12-10 13:53:16');
INSERT INTO `borrow_order` VALUES (7, 3, 4, 'Online Reservation', 1, '2025-12-10 13:55:59');
INSERT INTO `borrow_order` VALUES (8, 3, 5, 'Online Reservation', 1, '2025-12-10 13:56:02');
INSERT INTO `borrow_order` VALUES (9, 3, 6, 'Online Reservation', 0, '2025-12-10 13:56:04');

-- ----------------------------
-- Table structure for librarian
-- ----------------------------
DROP TABLE IF EXISTS `librarian`;
CREATE TABLE `librarian`  (
  `librarian_id` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `librarian_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `librarian_phone` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`librarian_id`) USING BTREE,
  INDEX `librarian_name`(`librarian_name` ASC) USING BTREE,
  INDEX `librarian_phone`(`librarian_phone` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of librarian
-- ----------------------------
INSERT INTO `librarian` VALUES ('L001', 'Alice Johnson', '555-2314');
INSERT INTO `librarian` VALUES ('L002', 'Mark Smith', '555-9823');
INSERT INTO `librarian` VALUES ('L003', 'Emma Brown', '555-7732');
INSERT INTO `librarian` VALUES ('L004', 'Brian Linde', '555-9283');

-- ----------------------------
-- Table structure for library_staff
-- ----------------------------
DROP TABLE IF EXISTS `library_staff`;
CREATE TABLE `library_staff`  (
  `staff_id` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `staff_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `assigned_section` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT 'Book section the staff manages',
  PRIMARY KEY (`staff_id`) USING BTREE,
  INDEX `staff_name`(`staff_name` ASC) USING BTREE,
  INDEX `assigned_section`(`assigned_section` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of library_staff
-- ----------------------------
INSERT INTO `library_staff` VALUES ('S001', 'wang wenwei', 'History');
INSERT INTO `library_staff` VALUES ('S002', 'yin mingye', 'Science Fiction');
INSERT INTO `library_staff` VALUES ('S003', 'lyu haoming', 'Classics');
INSERT INTO `library_staff` VALUES ('S004', 'you liangjun', 'Music');
INSERT INTO `library_staff` VALUES ('S005', 'xia chunqiu', 'Romanticism');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `password` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `telephone` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `role` int NOT NULL COMMENT '0=reader, 1=admin',
  `linked_librarian_id` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `username`(`username` ASC) USING BTREE,
  INDEX `telephone`(`telephone` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (2, 'alice', '123456789', '18067311581', 1, 'L001');
INSERT INTO `user` VALUES (3, 'tom', 'abcdef', '13936295057', 0, '');

-- ----------------------------
-- Table structure for user_profile
-- ----------------------------
DROP TABLE IF EXISTS `user_profile`;
CREATE TABLE `user_profile`  (
  `id` int UNSIGNED NULL DEFAULT NULL,
  `real_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `sex` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `age` int NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `username` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  INDEX `id`(`id` ASC) USING BTREE,
  CONSTRAINT `user_profile_ibfk_1` FOREIGN KEY (`id`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of user_profile
-- ----------------------------
INSERT INTO `user_profile` VALUES (2, 'Alice Johnson', 'Female', 22, 'alice@example.com', '18067311581', 'alice');
INSERT INTO `user_profile` VALUES (3, 'Tom Hardy', 'Male', 24, 'tom@example.com', '13936295057', 'tom');

-- ----------------------------
-- Triggers structure for table borrow_order
-- ----------------------------
DROP TRIGGER IF EXISTS `borrow_insert`;
delimiter ;;
CREATE TRIGGER `borrow_insert` AFTER INSERT ON `borrow_order` FOR EACH ROW BEGIN
  UPDATE borrow_method
  SET count = count + 1
  WHERE method_name = NEW.borrow_method;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table borrow_order
-- ----------------------------
DROP TRIGGER IF EXISTS `book_borrow_count`;
delimiter ;;
CREATE TRIGGER `book_borrow_count` AFTER INSERT ON `borrow_order` FOR EACH ROW BEGIN
  UPDATE book
  SET total_borrowed = total_borrowed + 1
  WHERE book.book_id = NEW.book_id; -- <-- 改为 book_id
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table borrow_order
-- ----------------------------
DROP TRIGGER IF EXISTS `borrow_update`;
delimiter ;;
CREATE TRIGGER `borrow_update` AFTER UPDATE ON `borrow_order` FOR EACH ROW BEGIN
  IF (NEW.borrow_method != OLD.borrow_method) THEN
    UPDATE borrow_method SET count = count - 1 WHERE method_name = OLD.borrow_method;
    UPDATE borrow_method SET count = count + 1 WHERE method_name = NEW.borrow_method;
  END IF;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table borrow_order
-- ----------------------------
DROP TRIGGER IF EXISTS `borrow_delete`;
delimiter ;;
CREATE TRIGGER `borrow_delete` AFTER DELETE ON `borrow_order` FOR EACH ROW BEGIN
  UPDATE borrow_method
  SET count = count - 1
  WHERE method_name = OLD.borrow_method;
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table borrow_order
-- ----------------------------
DROP TRIGGER IF EXISTS `book_borrow_delete`;
delimiter ;;
CREATE TRIGGER `book_borrow_delete` AFTER DELETE ON `borrow_order` FOR EACH ROW BEGIN
  UPDATE book
  SET total_borrowed = total_borrowed - 1
  WHERE book.book_id = OLD.book_id; -- <-- 改为 book_id
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
