<template>
    <div>
        <div class="header">待处理借阅</div>
        <div class="body">
            <el-table :data="tabledata" style="width: mid-width" border>
                <el-table-column prop="book_title" label="书名" min-width="200" align="center"/>
                <el-table-column prop="borrow_method" label="借阅方式" width="180" align="center"/>
                <el-table-column prop="borrow_time" label="申请时间" width="200" align="center"/>
                
                <!-- 只保留“取消”操作 -->
                <el-table-column label="操作" width="120" align="center">
                    <template slot-scope="scope">
                        <el-button size="small" type="danger" @click="remove(scope.row)">取消申请</el-button>
                    </template>
                </el-table-column>
            </el-table>

            <!-- 删除 "修改借阅信息" 的对话框 -->

            <el-dialog title="取消借阅" :visible.sync="dialog_delete" width="30%">
                <div>确认取消该借阅申请？</div>
                <div style="text-align:center; margin-top: 20px;">
                    <!-- 【重要】确认按钮绑定 doDelete 方法 -->
                    <el-button type="primary" @click="doDelete">确定</el-button>
                </div>
            </el-dialog>
        </div>
    </div>
</template>

<script>
export default {
    created() { this.getData(); },
    data() {
        return {
            tabledata: [],
            // 移除了 dialog_edit 和 form_edit
            dialog_delete: false,
            delete_id: ''
        }
    },
    methods: {
        getData() {
            this.$axios.get("/api/user/pending_borrow").then(res => {
                if (res.data.status === 200) {
                    this.tabledata = res.data.tabledata;
                }
            });
        },
        // 移除了 edit 和 doEdit 方法
        remove(row) {
            // 需要传递 borrow_id
            this.delete_id = row.borrow_id;
            this.dialog_delete = true;
        },
        doDelete() {
            // 【重要】后端需要一个删除接口
            // 假设接口是 /api/user/borrow_order
            this.$axios.delete("/api/user/borrow_order", {
                data: { borrow_id: this.delete_id }
            }).then(res => {
                if (res.data.status === 200) {
                    this.$message.success(res.data.msg);
                    this.dialog_delete = false;
                    this.getData();
                }
            }).catch(err => {
                this.$message.error('操作失败: ' + (err.response.data.msg || '未知错误'));
            });
        }
    }
}
</script>

<style scoped>
.header {
    text-align:center;font-size:20px;font-weight:800;padding:20px;border-bottom:1px solid #e3e3e3;
}
.body { width:70%; margin:auto; margin-top:30px; }
</style>
